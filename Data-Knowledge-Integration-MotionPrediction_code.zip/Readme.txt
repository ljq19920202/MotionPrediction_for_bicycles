This code mainly includes the following parts:

Main: main program, including the following contents:
1. Data preprocessing: output to E_trajectory.csv
2. Dataset splitting: obtain training, validation, and testing sets required for each model
3. Training
4. Testing part: includes trajectory generation and trajectory selection	
Prediction: testing part, prerequisite: completed training model; including trajectory generation
TrajectorySelection: trajectory selection part, including utility calculation of candidate trajectories
PredictionEvaluation: error calculation of predicted trajectories


This project provides a demonstration demo, including three trained models, testing IDs, and normalization parameters.


This project provides bicycle trajectory data: For the preprocessed E_trajectory.csv, its list represents:
Bicycle ID, Frame ID, Timestamp ID, px, py, vx, vy, ax, ay, v, a, curvature, vehicle type (1 for rb, 2 for eb, 3 for v).